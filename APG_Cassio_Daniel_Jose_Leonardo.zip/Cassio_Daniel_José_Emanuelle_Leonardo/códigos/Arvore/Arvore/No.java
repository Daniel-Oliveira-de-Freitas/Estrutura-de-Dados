package Arvore;
import main.Estudante;
public class No
{
    private No esq; 
    private No dir;
    private Estudante estud;
    private Integer matri;
    

    public No(Integer matri, Estudante estud) 
    {
        this.matri = matri;
        this.estud = estud;
    }
    
    public No()
    {
    
    }

    public No getEsquerda() 
    {
        return esq;
    }

    public void setEsquerda(No esq) 
    {
        this.esq = esq;
    }

    public No getDireita() 
    {
        return dir;
    }

    public void setDireita(No dir) 
    {
        this.dir = dir;
    }

    public Integer getMatricula() 
    {
        return matri;
    }

    public void setMatricula(Integer matri) 
    {
        this.matri = matri;
    }
    
    public Estudante getEstudante() 
    {
        return estud;
    }

    public void setEstudante(Estudante estud) 
    {
        this.estud = estud;
    }
}
