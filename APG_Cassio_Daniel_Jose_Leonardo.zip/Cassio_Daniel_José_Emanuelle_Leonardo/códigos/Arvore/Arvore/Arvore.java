package Arvore;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import main.Estudante;

public class Arvore implements Map<Integer, Estudante> 
{
    
    private No raiz;
    private long tempo_insercao;
    private long tempo_mostrar;
    private long tempo;
    private long tempo_remocao;
    private int nElementos;
    private int estudantes = 0;

    public Arvore(No raiz, int nElementos) 
    {
        this.raiz = raiz;
        this.nElementos = nElementos;
    }

    public Arvore(int nElementos) 
    {
        this.nElementos = nElementos;
    }

    public Arvore() 
    {
        this.raiz = null;
        this.nElementos = 0;
    }


    public No getRaiz() 
    {
        return raiz;
    }

    public void setRaiz(No raiz) 
    {
        this.raiz = raiz;
    }

    public int getnElementos() 
    {
        return nElementos;
    }

    public void setnElementos(int nElementos) 
    {
        this.nElementos = nElementos;
    }

    public int getEstudantes() 
    {
        return estudantes;
    }

    public void setEstudantesES(int estudantes) 
    {
        this.estudantes = estudantes;
    }

    public long getTempo_insercao() 
    {
        return tempo_insercao;
    }

    public void setTempo_insercao(long tempo_insercao) 
    {
        this.tempo_insercao = tempo_insercao;
    }

    public long getTempo_mostrar() 
    {
        return tempo_mostrar;
    }

    public void setTempo_mostrar(long tempo_mostrar) 
    {
        this.tempo_mostrar = tempo_mostrar;
    }

    public long getTempo() 
    {
        return tempo;
    }

    public void setTempo(long tempo) 
    {
        this.tempo = tempo;
    }

    public long getTempo_remocao() 
    {
        return tempo_remocao;
    }

    public void setTempo_remocao(long tempo_remocao) 
    {
        this.tempo_remocao = tempo_remocao;
    }

    
    public void inserir() 
    {
        long tempo = System.nanoTime();
        for (int i = 0; i < this.nElementos; i++) 
        {
            Estudante estudante = new Estudante();
            put(estudante.getMatricula(), estudante);
        }
        this.tempo_insercao = System.nanoTime() - tempo;
    }

    public void mostrarCrescente() 
    {
        long tempo = System.nanoTime();
        mostrar(this.raiz);
        this.tempo_mostrar = System.nanoTime() - tempo;
    }

    public void contarestES() 
    {
        long tempo = System.nanoTime();
        contar(this.raiz);
        this.tempo = System.nanoTime() - tempo;
    }

    
    public int contar(No no) 
    {
        if (no == null) 
        {
            return 0;
        }
        if (no.getEstudante().isCursoES()) 
        {
            this.estudantes++;
        }

        contar(no.getEsquerda());
        contar(no.getDireita());

        return this.estudantes;
    }

    public void remocao() {
        long tempo = System.nanoTime();

        for (int i = 0; i < 100000; i++) 
        {
            remove(menor202060000(this.raiz).getMatricula());
        }

        this.tempo_remocao = System.nanoTime() - tempo;
    }

    public void mostrar(No no) 
    {
        if (no != null) 
        {
            System.out.println("Matricula: " + no.getEstudante().getMatricula()
                    + " | Curso: " + no.getEstudante().getCurso());
            mostrar(no.getEsquerda());
            mostrar(no.getDireita());
        }
    }

    public No menor202060000(No no) 
    {
        if (no.getMatricula() < 202060000) 
        {
            return no;
        } else if (no.getMatricula() > 202060000) 
        {
            return menor202060000(no.getEsquerda());
        } else 
        {
            return menor202060000(no.getDireita());
        }
    }

    
    public int size(No no) 
    {
        if (no == null) 
        {
            return 0;
        } else {
            return size(no.getEsquerda()) + 1 + size(no.getDireita());
        }
    }

    @Override
    public int size() 
    {
        return size(this.raiz);
    }

    @Override
    public boolean isEmpty() 
    {
        return raiz.getEsquerda() == null && raiz.getDireita() == null;
    }

  
    public boolean containsKey(No no, Integer matricula) 
    {
        if (no.getMatricula().equals(matricula)) 
        {
            return true;
        } 
        
        else if (no.getMatricula() > matricula) 
        {
            return containsKey(no.getEsquerda(), matricula);
        } 
        
        else 
        {
            return containsKey(no.getDireita(), matricula);
        }
    }

    @Override
    public boolean containsKey(Object key) 
    {
        return containsKey(this.raiz, (Integer) key);
    }

    
    public boolean containsValue(No no, Estudante estudante) 
    {
        if (no.getEstudante().equals(estudante)) 
        {
            return true;
        } 
        
        else if (no.getMatricula() > estudante.getMatricula()) 
        {
            return containsValue(no.getEsquerda(), estudante);
        } 
        
        else 
        {
            return containsValue(no.getDireita(), estudante);
        }
    }

    @Override
    public boolean containsValue(Object value) 
    {
        return containsValue(this.raiz, (Estudante) value);
    }

   
    public Estudante get(No no, Integer matricula) 
    {
        if (no == null || no.getMatricula().equals(matricula)) 
        {
            return no.getEstudante();
        } else if (no.getMatricula() > matricula) 
        {
            return get(no.getEsquerda(), matricula);
        } else 
        {
            return get(no.getDireita(), matricula);
        }
    }

    @Override
    public Estudante get(Object key) 
    {
        return get(this.raiz, (Integer) key);
    }

    public No put(No no, Integer matricula, Estudante estudante) 
    {
        if (no == null) 
        {
            No aux = new No(matricula, estudante);
            if (this.raiz == null) 
            {
                this.raiz = aux;
            }
            return aux;
        }
        
        if (matricula < no.getMatricula()) 
        {
            no.setEsquerda(put(no.getEsquerda(), matricula, estudante));
        } 
        
        else if (matricula > no.getMatricula())
        {
            no.setDireita(put(no.getDireita(), matricula, estudante));
        }
        return no;
    }

    @Override
    public Estudante put(Integer key, Estudante value) 
    {
        return put(this.raiz, key, value).getEstudante();
    }

    public No remove(No no, Integer matricula) 
    {
        if (no == null) 
        {
            return no;
        }

        if (matricula < no.getMatricula()) 
        {
            no.setEsquerda(remove(no.getEsquerda(), matricula));
        } 
        
        else if (matricula > no.getMatricula()) 
        {
            no.setDireita(remove(no.getDireita(), matricula));

        } 
        
        else 
        {
            if (no.getEsquerda() == null) 
            {
                return no.getDireita();
            } 
            
            else if (no.getDireita() == null) 
            {
                return no.getEsquerda();
            }

            matricula = valorMenor(no.getDireita());
            no.setDireita(remove(no.getDireita(), matricula));
        }
        return no;
    }

    public int valorMenor(No no) 
    {
        int menor = this.raiz.getMatricula();
        while (no.getEsquerda() != null) {
            menor = no.getEsquerda().getMatricula();
            no = no.getEsquerda();
        }
        return menor;
    }

    @Override
    public Estudante remove(Object key) 
    {
        return remove(this.raiz, (Integer) key).getEstudante();
    }

    @Override
    public void putAll(Map<? extends Integer, ? extends Estudante> m) 
    {
        throw new UnsupportedOperationException(); 
    }

    @Override
    public void clear() 
    {
        this.raiz = null;
    }

    @Override
    public Set<Integer> keySet() 
    {
        Set<Integer> keys = null;

        keys.add(percorrer(raiz).getMatricula());

        return keys;
    }

    public No percorrer(No no) 
    {
        if (no != null) {
            return null;
        }
        percorrer(no.getEsquerda());
        percorrer(no.getDireita());
        return no;
    }

    @Override
    public Collection<Estudante> values() 
    {
        Collection<Estudante> collectionEstudantes = null;

        collectionEstudantes.add(percorrer(this.raiz).getEstudante());
        return collectionEstudantes;
    }

    @Override
    public Set<Entry<Integer, Estudante>> entrySet() 
    {
        throw new UnsupportedOperationException(); 
    }
}
