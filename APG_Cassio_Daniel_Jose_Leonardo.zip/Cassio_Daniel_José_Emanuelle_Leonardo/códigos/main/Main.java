package main;
import Arvore.Arvore;
import vetor.Vetor;
public class Main 
{

    public static void main(String[] args) 
    {
        Lista_Duplamente_Encadeada lde = new Lista_Duplamente_Encadeada(100000);
        Arvore arvore = new Arvore(100000);
        //analise de insercao
        //insercao(lde, arvore);
        //analise de ordenacao
        //ordenacao(lde, arvore);
        //analise de contagem
        //contarES(lde, arvore);
        //analise de remocao
        //remocao(lde, arvore);
        //chamada do metodo que exibe os dados da LDE
        //lista();
        //chamada do metodo que exibe os dados da arvore
        //arvore();
        //vetor();
    }

    //metodo de analise da insercao de 100000 estudantes
    public static void insercao(Lista_Duplamente_Encadeada listaDupla, Arvore arvore) 
    {
        System.out.println("INSERCAO DE 100000 ESTUDANTES");
        listaDupla.inserir();
        System.out.println("Lista duplamente encadeada - Tempo decorrido: " + listaDupla.getTempo_insercao() + "ms");
        arvore.inserir();
        System.out.println("Arvore - Tempo decorrido: " + arvore.getTempo_insercao() + "ms");
        System.out.println("");
    }

    //metodo de analise da ordenacao crescente
    public static void ordenacao(Lista_Duplamente_Encadeada listaDupla, Arvore arvore) 
    {
        System.out.println("ORDENACAO CRESCENTE");
        System.out.println("");
        System.out.println("-- Ordenando e mostrando Lista duplamente encadeada --");
        listaDupla.ordenar();
        System.out.println("-- Mostrando Arvore --");
        arvore.mostrarCrescente();
        System.out.println("Lista duplamente encadeada - Tempo decorrido: " + listaDupla.getTempo_ordem() + "ms");
        System.out.println("Arvore - Tempo decorrido: " + arvore.getTempo_mostrar() + "ms");
        System.out.println("");
    }
    
    //metodo de contagem dos estudantes de Engenharia de Software
    public static void contarES(Lista_Duplamente_Encadeada listaDupla, Arvore arvore) {
        System.out.println("CONTAGEM ESTUDANTES DE ES");
        listaDupla.contarES();
        System.out.println("Lista duplamente encadeada - Tempo decorrido dos " + listaDupla.getEstudantes() + " estudantes: " + listaDupla.getTempo() + "ms");
        arvore.contarES();
        System.out.println("Arvore - Tempo decorrido dos "
                + arvore.getEstudantes() + " estudantes: " + arvore.getTempo() + "ms");
    }

    //metodo de analise da remocao de estudantes com matricula <= 202060000
    public static void remocao(Lista_Duplamente_Encadeada listaDupla, Arvore arvore) {
        System.out.println("Remocao estudantes <= 202060000");
        listaDupla.remocao();
        System.out.println("Lista duplamente encadeada - Tempo decorrido: " + listaDupla.getTempo_remocao() + "ms");
        arvore.remocao();
        System.out.println("Arvore - Tempo decorrido: " + arvore.getTempo_remocao() + "ms");
        System.out.println("");
    }

    //metodo de analise da lsta duplamente encadeada
    public static void lista() 
    {
        System.out.println("Lista duplamente encadeada");
        Lista_Duplamente_Encadeada lista = new Lista_Duplamente_Encadeada(100000);
        lista.inserir();
        System.out.println("Tempo decorrido para insercao de 100.000 estudantes: " + lista.getTempo_insercao() + "ms");
        lista.ordenar();
        lista.mostrar();
        System.out.println("Tempo decorrido para ordenacao crescente: " + lista.getTempo_ordem() + "ms");
        lista.contarES();
        System.out.println("Tempo decorrido para contagem dos " + lista.getEstudantes() + " estudantes de ES: " + lista.getTempo() + "ms");
        lista.remocao();
        System.out.println("Tempo decorrido para remocao dos estudantes com matricula <= 202060000: " + lista.getTempo_remocao() + "ms");
        System.out.println("--- || ---");
    }
    
  //metodo de analise da arvore
    public static void arvore() 
    {
        System.out.println("Arvore");
        Arvore arvore = new Arvore(100000);
        arvore.inserir();
        System.out.println("Tempo decorrido para insercao de 100.000 estudantes: " + arvore.getTempo_insercao() + "ms");
        arvore.mostrarCrescente();
        System.out.println("Tempo decorrido para mostrar crescente: " + arvore.getTempo_mostrar() + "ms");
        arvore.contarES();
        System.out.println("Tempo decorrido para contagem dos estudantes de ES ("
                + arvore.getEstudantes() + ") : " + arvore.getTempo() + "ms");
        arvore.remocao();
        System.out.println("Tempo decorrido para remoção dos estudantes com matrícula <= 20205000: " + arvore.getTempo_remocao() + "ms");
        System.out.println("--- || ---");
    }
    
    public static void vetor() {
    	System.out.println("Vetor ordenado");
    	Vetor vetor = new Vetor(100000);
    	vetor.inserir();
    	System.out.println("Tempo para inserir os alunos no vetor: " + vetor.getTempo_insercao());
    	vetor.ordenar();
    	System.out.println("Tempo para apresentar os alunos em ordem crescente: " + vetor.getTempo_ordem());
    	vetor.contarES();;
    	System.out.println("Tempo para contar os alunos de Engenharia de Software do vetor: " + System.nanoTime() + " Numero de alunos: " + vetor.getTempo_es());
    	vetor.remocao();
    	System.out.println("Tempo para remover os alunos com matricula de 202060000 do vetor: " + vetor.getTempo_remocao());
    }

    public static double segundos(long tempo) {
        return (double) tempo / 1_000_000_000.0;
    }
}
